export const authConstants = {
  secret: 'HAD_12X#@',
};
