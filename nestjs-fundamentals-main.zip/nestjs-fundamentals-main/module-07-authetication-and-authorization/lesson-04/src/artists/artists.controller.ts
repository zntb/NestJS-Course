import { Controller } from '@nestjs/common';

@Controller('artists')
export class ArtistsController {}
