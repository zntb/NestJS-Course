export interface PayloadType {
  email: string;
  userId: number;
  artistId?: number;
}
