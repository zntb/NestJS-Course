export const connection: Connection = {
  CONNECTION_STRING: 'MYSQL://12324/sad',
  DB: 'MYSQL',
  DBNAME: 'TEST',
};
export type Connection = {
  CONNECTION_STRING: string;
  DB: string;
  DBNAME: string;
};
